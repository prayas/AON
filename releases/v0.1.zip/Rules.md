# Rules

![rules_Page_2](https://user-images.githubusercontent.com/27791/187026332-3e5a58ce-b7f2-4eab-91de-c08e4ce187e1.png)

![rules_Page_1](https://user-images.githubusercontent.com/27791/187026334-ffb5c11b-cbc0-4314-ac4c-feab9b55ecde.png)
